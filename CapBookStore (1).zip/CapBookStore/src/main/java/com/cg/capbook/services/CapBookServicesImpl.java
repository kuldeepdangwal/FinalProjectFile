package com.cg.capbook.services;

import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import com.cg.capbook.beans.Album;
import com.cg.capbook.beans.Images;
import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.PostDislike;
import com.cg.capbook.beans.PostLike;
import com.cg.capbook.beans.Users;
import com.cg.capbook.daoservices.PostDAO;
import com.cg.capbook.daoservices.UserDAO;
import com.cg.capbook.exceptions.EmailAlreadyExistException;
import com.cg.capbook.exceptions.PasswordMismatchException;
import com.cg.capbook.exceptions.SecurityAnswerMismatchException;
import com.cg.capbook.exceptions.SecurityQuestionMismatchException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

@Component("capBookServices")
public class CapBookServicesImpl implements CapBookServices {

//	String url="C:\\Users\\ADM-IG-HWDLAB1D\\git\\CapBookLocalRepoTeam7\\CapBookStore\\src\\main\\resources\\static\\images\\UserImages\\";
//	String url = "D:\\Program Files\\sts-bundle\\Final Project\\CAPBOOK_TEAM7\\CapBookStore\\src\\main\\resources\\static\\images\\UserImages\\";
	String url = "D:\\TirtharajSur_Capbook\\CapBookStore\\src\\main\\resources\\static\\images\\UserImages\\";

	@Autowired
	private UserDAO  userDao;
	@Autowired
	private PostDAO postDao;
	
	@Override
	public Users acceptUserDetails(Users user) throws UserDetailsNotFoundException, EmailAlreadyExistException {
		String password=user.getPassword();
		user.setPassword(encryptPassword(password));
		user.setJoinDate(parseDate());
		return userDao.save(user);
	}

	@Override
	public Users getUserDetails(String emailId) throws UserDetailsNotFoundException {
		return userDao.findById(emailId).orElseThrow(()->new UserDetailsNotFoundException("user does not exist!!"));
	}

	@Override
	public boolean deleteUserDetails(String emailId) throws UserDetailsNotFoundException {
		userDao.delete(getUserDetails(emailId));
		return true;
	}

	@Override
	public Users updateUserDetails(Users user) throws UserDetailsNotFoundException {
		return userDao.save(user);
	}

	@Override
	public String encryptPassword(String password) {
		return Base64.getMimeEncoder().encodeToString(password.getBytes());
	}

	@Override
	public String decryptPassword(String password) {
		return new String(Base64.getMimeDecoder().decode(password));
	}

	@Override
	public boolean changePassword(String emailId,String newPassword,String confirmPassword) throws UserDetailsNotFoundException,PasswordMismatchException {
		Users user= getUserDetails(emailId);
		String oldPassword=user.getPassword();
		if(oldPassword.equals(newPassword))
			throw new PasswordMismatchException("New password can not be same as old password. Please re-enter new password.");
		else 
			if(!(newPassword.equals(confirmPassword))) {
				throw new PasswordMismatchException("Confirm Password and New Password should be same.");
			}		
		user.setPassword(confirmPassword);
		userDao.save(user);
		return true;
	}

//	@Override
//	public Post savePost(Post post) {
//		post.setPostDate(parsedDate);
//		post.setPostTime(parsedTime);
//		return postDao.save(post);
//	}

	@Override
	public List<Post> getAllPost() {
		List<Post> post=postDao.findAll();
		Collections.sort(post,Collections.reverseOrder());
		return post;
	}
//	@Override
//	public Post saveAlbumImages(String emailId,MultipartFile file) throws UserDetailsNotFoundException{
//		List<Images> imageList=new ArrayList<>();
//		Post post=new Post();
//		Album album=new Album();
//		Users user=getUserDetails(emailId);
//		post.setUser(user);
//		try {
//			file.transferTo(Paths.get(url+file.getOriginalFilename()));
//			System.out.println(file.getOriginalFilename());
//			Images image=new Images(file.getOriginalFilename(), "resources/images/UserImages/"+file.getOriginalFilename());
//			imageList.add(image);
//			album.setImages(imageList);
//		} catch (IllegalStateException | IOException e) {
//			e.printStackTrace();
//		}
//		album.setPost(post);
//		post.setAlbum(album);
//		return 	savePost(post);
//	}

	@Override
	public boolean forgetPassword(Users user) throws UserDetailsNotFoundException, SecurityAnswerMismatchException, SecurityQuestionMismatchException {
		String emailId=user.getEmailId();
		String securityQuestion=user.getSecurityQuestion();
		String securityAnswer=user.getSecurityAnswer();
		Users userValidate = getUserDetails(emailId);
		if(userValidate.getSecurityQuestion().equals(securityQuestion)) {
			if(userValidate.getSecurityAnswer().equals(securityAnswer)) {
				userValidate.setPassword(encryptPassword(user.getPassword()));
				userDao.save(userValidate);
				return true;
			}
			else throw new SecurityAnswerMismatchException("Security answer Mismatch");
		}
		else throw new SecurityQuestionMismatchException("Security Question Mismatch");
	}

	@Override
	public LocalDate parseDate() {
		LocalDate joinDate = LocalDate.now();
		DateTimeFormatter formatters =DateTimeFormatter.ofPattern("yyyyMMdd");
		String text=joinDate.format(formatters);
		LocalDate parsedDate = LocalDate.parse(text,formatters); 
		return parsedDate;
	}
	
	@Override
	public LocalTime parseTime() {
		LocalTime nowTime = LocalTime.now();    
		DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm:ss");  
		String formatTime = nowTime.format(timeFormat);  
		LocalTime parsedTime = LocalTime.parse(formatTime,timeFormat); 
		return parsedTime;
	}

	@Override
	public Post savePost(Post post,String emailId ,MultipartFile file) throws UserDetailsNotFoundException {
		 post.setPostDate(parseDate());
		post.setPostTime(parseTime());
		
		List<Images> imageList=new ArrayList<>();
		Album album=new Album();
		Users user=getUserDetails(emailId);
		post.setUser(user);
		try {
			file.transferTo(Paths.get(url+file.getOriginalFilename()));
			Images image=new Images(file.getOriginalFilename(), "resources/images/UserImages/"+file.getOriginalFilename());
			imageList.add(image);
			album.setImages(imageList);
		} catch (IllegalStateException | IOException e) {
			e.printStackTrace();
		}
		album.setPost(post);
		post.setAlbum(album);
		return postDao.save(post);
	}

	@Override
	public Post saveLikes(String senderEmailId,Post post) throws Exception {
		int postId=post.getPostId();
		List<PostLike>postLikeList=new ArrayList<PostLike>();
		PostLike postLike=new PostLike();
		postLike.setSenderEmailId(senderEmailId);
		postLikeList.add(postLike);
		post=postDao.findById(postId).orElseThrow(()->new Exception("exception"));
		int noOfLikes=post.getNoOfLikes();
		noOfLikes++;
		post.setNoOfLikes(noOfLikes);
		post.setPostLikes(postLikeList);
		post=postDao.save(post);
		return post;
	}

	@Override
	public Post saveDislikes(String senderEmailId, Post post) throws Exception {
		int postId=post.getPostId();
		List<PostDislike>postDislikeList=new ArrayList<PostDislike>();
		PostDislike postDislike=new PostDislike();
		postDislike.setSenderEmailId(senderEmailId);
		postDislikeList.add(postDislike);
		post=postDao.findById(postId).orElseThrow(()->new Exception("exception"));
		int noOfDislikes=post.getNoOfDislikes();
		noOfDislikes++;
		post.setNoOfDislikes(noOfDislikes);
		post.setPostDislikes(postDislikeList);
		post=postDao.save(post);
		return post;
	}
}