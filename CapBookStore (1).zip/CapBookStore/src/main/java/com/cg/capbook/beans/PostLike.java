package com.cg.capbook.beans;

import javax.persistence.Embeddable;

@Embeddable
public class PostLike {
	private String senderEmailId;
	public PostLike() {}
	public PostLike(String senderEmailId) {
		super();
		this.senderEmailId = senderEmailId;
	}
	public String getSenderEmailId() {
		return senderEmailId;
	}
	public void setSenderEmailId(String senderEmailId) {
		this.senderEmailId = senderEmailId;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((senderEmailId == null) ? 0 : senderEmailId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PostLike other = (PostLike) obj;
		if (senderEmailId == null) {
			if (other.senderEmailId != null)
				return false;
		} else if (!senderEmailId.equals(other.senderEmailId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "PostLike [senderEmailId=" + senderEmailId + "]";
	}
}