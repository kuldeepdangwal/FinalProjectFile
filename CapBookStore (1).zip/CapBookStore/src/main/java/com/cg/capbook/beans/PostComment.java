package com.cg.capbook.beans;

import javax.persistence.Embeddable;

@Embeddable
public class PostComment {

}
