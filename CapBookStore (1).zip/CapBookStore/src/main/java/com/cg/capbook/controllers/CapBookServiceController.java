package com.cg.capbook.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.Users;
import com.cg.capbook.exceptions.EmailAlreadyExistException;
import com.cg.capbook.exceptions.SecurityAnswerMismatchException;
import com.cg.capbook.exceptions.SecurityQuestionMismatchException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.CapBookServices;

@Controller
@SessionAttributes("emailId")
public class CapBookServiceController {
	@Autowired
	CapBookServices services;

	@RequestMapping("/registerUserService")
	public ModelAndView registerUser(@Valid@ModelAttribute Users user,BindingResult result) throws UserDetailsNotFoundException, EmailAlreadyExistException {
		if(result.hasErrors()) return new ModelAndView("registrationPage");
		services.acceptUserDetails(user);
		return new ModelAndView("indexPage","regsuccess","SCCESSFULLY REGISTERED!");
	}

	@RequestMapping("/loginUserService")
	public ModelAndView getUserDetails(@RequestParam String emailId, @RequestParam String password,ModelMap model) throws UserDetailsNotFoundException{ 
		String encryptedPassword=services.encryptPassword(password);
		Users user=null;
		try {
			user = services.getUserDetails(emailId);
		} catch (UserDetailsNotFoundException e) {
			 return new ModelAndView("indexPage","errorMessage", e.getMessage());
		}
		String originalEncryptedPassword=user.getPassword();
		if(originalEncryptedPassword.equals(encryptedPassword)) {
			model.put("emailId", user.getEmailId());
			model.put("posts", services.getAllPost());
			ModelAndView mod=new ModelAndView("homePage","emailId",emailId);
			mod.addObject("allPosts", services.getAllPost());
			return mod;
		}
		return new ModelAndView("indexPage","errorMessage","Password is not correct!");
	}

	@RequestMapping("/userProfileService")
	public ModelAndView userProfile(@SessionAttribute("emailId") String emailId) throws UserDetailsNotFoundException {
		Users user=services.getUserDetails(emailId);
		return new ModelAndView("accountSettingsPage","user",user);
	}
	
	@RequestMapping("/updateProfileService")
	public ModelAndView saveAccountUpdateService(@SessionAttribute("emailId") String emailId,Users user) throws UserDetailsNotFoundException {
		user.setEmailId(emailId);
		user=services.getUserDetails(emailId);
		user=services.updateUserDetails(user);
		return new ModelAndView("accountSettingsPage","user",user);
	}

	@RequestMapping("/forgetPasswordService")
	public ModelAndView forgetPassword(@ModelAttribute Users user){
		try {
			if(services.forgetPassword(user))
				return new ModelAndView("indexPage","reply","PASSWORD SUCCESSFULLY CHANGED!");
		} catch (UserDetailsNotFoundException e) {
			return new ModelAndView("indexPage","reply",e.getMessage());
		} catch (SecurityAnswerMismatchException e) {
			return new ModelAndView("indexPage","reply",e.getMessage());
		} catch (SecurityQuestionMismatchException e) {
			return new ModelAndView("indexPage","reply",e.getMessage());
		}
		return null;
	}

//	@RequestMapping("/saveAlbumService")
//	public ModelAndView saveAlbumPicture(@SessionAttribute("emailId") String emailId,@RequestParam MultipartFile file) throws UserDetailsNotFoundException{
//		Post post=services.saveAlbumImages(emailId,file);
//		return new ModelAndView("homePage","posts",post);
//	}
//
//	@RequestMapping("/postStatusService")
//	public ModelAndView savePostStatus(@ModelAttribute Post post,@SessionAttribute("emailId") String emailId) throws UserDetailsNotFoundException{ 
//		post.setUser(services.getUserDetails(emailId));
//		services.savePost(post);
//		return new ModelAndView("homePage","posts",post);
//	}

	@RequestMapping("/postService")
	public ModelAndView savePostDetails(@ModelAttribute Post post,@SessionAttribute("emailId") String emailId,@RequestParam MultipartFile file) throws UserDetailsNotFoundException{ 
		post.setUser(services.getUserDetails(emailId));
		services.savePost(post,emailId ,file);
		return new ModelAndView("homePage","allPosts",services.getAllPost());
	}
	
//	@RequestMapping("/getAllPostService")
//	public ModelAndView getAllPostService(){
//		return new ModelAndView("homePage","allPosts",services.getAllPost());
//	}
	
	@RequestMapping("/likeService")
	public ModelAndView savePostLike(@ModelAttribute Post post,@SessionAttribute("emailId") String emailId) throws Exception {
		String senderEmailId=emailId;
		post=services.saveLikes(senderEmailId, post);
		List<Post>allPosts=services.getAllPost();
		return new ModelAndView("homePage","allPosts",allPosts);
	}
	
	@RequestMapping("/dislikeService")
	public ModelAndView savePostDislike(@ModelAttribute Post post,@SessionAttribute("emailId") String emailId) throws Exception {
		String senderEmailId=emailId;
		post=services.saveDislikes(senderEmailId, post);
		List<Post>allPosts=services.getAllPost();
		return new ModelAndView("homePage","allPosts",allPosts);
	}
}