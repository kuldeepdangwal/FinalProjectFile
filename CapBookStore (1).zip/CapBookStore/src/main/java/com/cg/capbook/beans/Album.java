package com.cg.capbook.beans;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;
@Entity
public class Album {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int albumId;
	private String albumName;
	private LocalDateTime albumDateTime;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Post post;
	
	@ElementCollection
	@JoinTable
	private List<Images> images;
	
	public Album() {}
	
	public Album(int albumId, String albumName, LocalDateTime albumDateTime, Post post, List<Images> images) {
		super();
		this.albumId = albumId;
		this.albumName = albumName;
		this.albumDateTime = albumDateTime;
		this.post = post;
		this.images = images;
	}
	
	public int getAlbumId() {
		return albumId;
	}
	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}
	public String getAlbumName() {
		return albumName;
	}
	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}
	public LocalDateTime getAlbumDateTime() {
		return albumDateTime;
	}
	public void setAlbumDateTime(LocalDateTime albumDateTime) {
		this.albumDateTime = albumDateTime;
	}
	public Post getPost() {
		return post;
	}
	public void setPost(Post post) {
		this.post = post;
	}
	public List<Images> getImages() {
		return images;
	}
	public void setImages(List<Images> images) {
		this.images = images;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((albumDateTime == null) ? 0 : albumDateTime.hashCode());
		result = prime * result + albumId;
		result = prime * result + ((albumName == null) ? 0 : albumName.hashCode());
		result = prime * result + ((images == null) ? 0 : images.hashCode());
		result = prime * result + ((post == null) ? 0 : post.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Album other = (Album) obj;
		if (albumDateTime == null) {
			if (other.albumDateTime != null)
				return false;
		} else if (!albumDateTime.equals(other.albumDateTime))
			return false;
		if (albumId != other.albumId)
			return false;
		if (albumName == null) {
			if (other.albumName != null)
				return false;
		} else if (!albumName.equals(other.albumName))
			return false;
		if (images == null) {
			if (other.images != null)
				return false;
		} else if (!images.equals(other.images))
			return false;
		if (post == null) {
			if (other.post != null)
				return false;
		} else if (!post.equals(other.post))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Album [albumId=" + albumId + ", albumName=" + albumName + ", albumDateTime=" + albumDateTime + ", post="
				+ post + ", images=" + images + "]";
	}
}
